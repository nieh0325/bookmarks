document.addEventListener('DOMContentLoaded', () => {
    const bookmarkManager = new BookmarkManager();
    const form = document.getElementById('bookmarkForm');
    const bookmarksList = document.getElementById('bookmarksList');
    const categoryTabs = document.getElementById('categoryTabs');
    let currentCategory = 'all';
    let editingId = null;

    // 載入已保存的書籤
    bookmarkManager.loadBookmarks();
    renderBookmarks();

    // 處理分類標籤點擊
    categoryTabs.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            // 更新活動標籤
            document.querySelector('.bookmark-nav li.active')?.classList.remove('active');
            e.target.classList.add('active');
            
            // 更新當前分類並重新渲染
            currentCategory = e.target.dataset.category;
            renderBookmarks();
        }
    });

    // 處理表單提交
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const title = document.getElementById('title').value;
        const url = document.getElementById('url').value;
        const category = document.getElementById('category').value;
        const description = document.getElementById('description').value;

        if (editingId) {
            bookmarkManager.editBookmark(editingId, {
                title, url, category, description
            });
            editingId = null;
            form.querySelector('button[type="submit"]').textContent = '添加書籤';
        } else {
            bookmarkManager.addBookmark(title, url, category, description);
        }

        renderBookmarks();
        form.reset();
    });

    // 渲染書籤列表
    function renderBookmarks() {
        const currentLang = localStorage.getItem('language') || 'zh-TW';
        const t = translations[currentLang];
        
        const bookmarks = bookmarkManager.getAllBookmarks();
        const filteredBookmarks = currentCategory === 'all' 
            ? bookmarks 
            : bookmarks.filter(b => b.category === currentCategory);

        bookmarksList.innerHTML = filteredBookmarks.map(bookmark => {
            let categoryText = bookmark.category;
            if (!categoryText) {
                categoryText = t.uncategorized;
            } else if (categoryText === '工作') {
                categoryText = t.work;
            } else if (categoryText === '學習') {
                categoryText = t.study;
            } else if (categoryText === '娛樂') {
                categoryText = t.entertainment;
            } else if (categoryText === '其他') {
                categoryText = t.other;
            }

            return `
                <div class="bookmark-item">
                    <div class="bookmark-title">${bookmark.title}</div>
                    <a href="${bookmark.url}" class="bookmark-url" target="_blank">${bookmark.url}</a>
                    <div class="bookmark-category">${categoryText}</div>
                    <div class="bookmark-description">${bookmark.description}</div>
                    <div class="bookmark-actions">
                        <button class="edit-btn" onclick="editBookmark(${bookmark.id})">${t.editBookmark}</button>
                        <button class="delete-btn" onclick="deleteBookmark(${bookmark.id})">${t.deleteBookmark}</button>
                    </div>
                </div>
            `;
        }).join('');

        // 更新分類標籤
        document.querySelectorAll('#categoryTabs li').forEach(li => {
            const category = li.dataset.category;
            if (category === 'all') {
                li.textContent = t.all;
            } else if (category === '工作') {
                li.textContent = t.work;
            } else if (category === '學習') {
                li.textContent = t.study;
            } else if (category === '娛樂') {
                li.textContent = t.entertainment;
            } else if (category === '其他') {
                li.textContent = t.other;
            }
        });

        // 更新表單元素
        document.querySelector('#title').placeholder = t.title_placeholder;
        document.querySelector('#url').placeholder = t.url_placeholder;
        document.querySelector('#description').placeholder = t.description_placeholder;
        document.querySelector('#bookmarkForm button[type="submit"]').textContent = 
            editingId ? t.saveChanges : t.addBookmark;

        // 更新類別選擇器
        const categorySelect = document.querySelector('#category');
        if (categorySelect) {
            categorySelect.innerHTML = `
                <option value="">${t.selectCategory}</option>
                <option value="工作">${t.work}</option>
                <option value="學習">${t.study}</option>
                <option value="娛樂">${t.entertainment}</option>
                <option value="其他">${t.other}</option>
            `;
        }
    }

    // 編輯書籤
    window.editBookmark = (id) => {
        const bookmark = bookmarkManager.bookmarks.find(b => b.id === id);
        if (bookmark) {
            document.getElementById('title').value = bookmark.title;
            document.getElementById('url').value = bookmark.url;
            document.getElementById('category').value = bookmark.category;
            document.getElementById('description').value = bookmark.description;
            
            editingId = id;
            form.querySelector('button[type="submit"]').textContent = '保存修改';
        }
    };

    // 刪除書籤
    window.deleteBookmark = (id) => {
        if (confirm('確定要刪除這個書籤嗎？')) {
            bookmarkManager.deleteBookmark(id);
            renderBookmarks();
        }
    };

    // 在現有代碼中添加設定相關功能
    const settingsBtn = document.getElementById('settingsBtn');
    const settingsPanel = document.getElementById('settingsPanel');
    const cancelSettings = document.getElementById('cancelSettings');
    const saveSettings = document.getElementById('saveSettings');
    const headerTitle = document.getElementById('headerTitle');
    const themeInputs = document.querySelectorAll('input[name="theme"]');
    const languageSelect = document.getElementById('languageSelect');
    const mainHeader = document.querySelector('h1'); // 獲取主標題元素

    // 保存設定前的臨時變量
    let tempHeaderTitle = '';

    // 設定面板開關
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.add('active');
        // 保存當前值作為臨時值
        tempHeaderTitle = mainHeader.textContent;
        headerTitle.value = tempHeaderTitle;
    });

    // 取消設定
    cancelSettings.addEventListener('click', () => {
        // 恢復原始值
        mainHeader.textContent = tempHeaderTitle;
        settingsPanel.classList.remove('active');
    });

    // 保存設定
    saveSettings.addEventListener('click', () => {
        try {
            const newTitle = headerTitle.value.trim();
            const selectedLang = languageSelect.value;
            const selectedTheme = document.querySelector('input[name="theme"]:checked').value;

            // 保存語言設定
            localStorage.setItem('language', selectedLang);

            // 保存標題設定
            if (newTitle) {
                localStorage.setItem('headerTitle', newTitle);
                mainHeader.textContent = newTitle;
                tempHeaderTitle = newTitle;
            } else {
                // 如果標題為空，使用當前語言的預設標題
                localStorage.removeItem('headerTitle');
                mainHeader.textContent = translations[selectedLang].title;
                tempHeaderTitle = translations[selectedLang].title;
            }

            // 保存主題設定
            localStorage.setItem('theme', selectedTheme);
            applyTheme(selectedTheme);

            // 更新界面
            updateLanguage(selectedLang);

            // 更新臨時標題值
            tempHeaderTitle = mainHeader.textContent;

            // 關閉設定面板
            settingsPanel.classList.remove('active');

        } catch (error) {
            console.error('保存設定時出錯：', error);
            alert('保存設定失敗，請重試');
        }
    });

    // 點擊外部關閉設定面板時也要恢復原始值
    settingsPanel.addEventListener('click', (e) => {
        if (e.target === settingsPanel) {
            mainHeader.textContent = tempHeaderTitle;
            settingsPanel.classList.remove('active');
        }
    });

    // 主題切換相關的變量定義
    let currentTheme = localStorage.getItem('theme') || 'light';

    // 應用主題的函數
    function applyTheme(theme) {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark-theme');
            document.body.classList.add('dark-theme');
        } else {
            document.documentElement.classList.remove('dark-theme');
            document.body.classList.remove('dark-theme');
        }
        localStorage.setItem('theme', theme);
        currentTheme = theme;
    }

    // 主題切換事件監聽
    themeInputs.forEach(input => {
        // 設置初始狀態
        if (input.value === currentTheme) {
            input.checked = true;
        }
        
        input.addEventListener('change', (e) => {
            const newTheme = e.target.value;
            applyTheme(newTheme);
            
            // 立即更新設定面板的外觀
            const settingsPanel = document.getElementById('settingsPanel');
            if (newTheme === 'dark') {
                settingsPanel.classList.add('dark-theme');
            } else {
                settingsPanel.classList.remove('dark-theme');
            }
        });
    });

    // 語言切換
    languageSelect.addEventListener('change', (e) => {
        const lang = e.target.value;
        localStorage.setItem('language', lang);
        updateLanguage(lang);
    });

    // 添加語言更新函數
    function updateLanguage(lang) {
        try {
            const t = translations[lang];
            
            // 更新頁面標題和抬頭名稱
            document.title = t.title;
            const savedHeaderTitle = localStorage.getItem('headerTitle');
            
            // 更新抬頭名稱
            if (!savedHeaderTitle) {
                mainHeader.textContent = t.title;
                headerTitle.value = t.title;
                tempHeaderTitle = t.title;
            }

            // 更新搜索區域
            document.querySelectorAll('.search-form').forEach(form => {
                const input = form.querySelector('input');
                const button = form.querySelector('button');
                const searchEngine = input.getAttribute('data-search-engine');
                
                if (searchEngine) {
                    // 根據當前語言更新搜索框佔位符
                    switch(searchEngine) {
                        case 'Google':
                            input.placeholder = t.googleSearch;
                            break;
                        case 'Bing':
                            input.placeholder = t.bingSearch;
                            break;
                        case 'Yahoo':
                            input.placeholder = t.yahooSearch;
                            break;
                        case 'DuckDuckGo':
                            input.placeholder = t.duckduckgoSearch;
                            break;
                    }
                    // 更新搜索按鈕文字
                    button.textContent = t.search;
                }
            });

            // 確保所有搜索按鈕都被更新
            document.querySelectorAll('.search-input-group button').forEach(button => {
                button.textContent = t.search;
            });

            // 更新設定面板文字
            document.querySelector('.settings-label').textContent = t.settings;
            document.querySelector('.settings-content h2').textContent = t.settings;
            
            // 更新設定區域標題和內容
            const settingSections = document.querySelectorAll('.settings-section');
            settingSections.forEach((section, index) => {
                const h3 = section.querySelector('h3');
                if (index === 0) {
                    h3.textContent = t.headerName;
                    section.querySelector('input').placeholder = t.inputHeaderName;
                }
                if (index === 1) {
                    h3.textContent = t.themeSettings;
                    const lightLabel = section.querySelector('label[for="light"]');
                    const darkLabel = section.querySelector('label[for="dark"]');
                    if (lightLabel) {
                        const sunEmoji = lightLabel.querySelector('span').textContent;
                        lightLabel.innerHTML = `<span>${sunEmoji}</span> ${t.lightTheme}`;
                    }
                    if (darkLabel) {
                        const moonEmoji = darkLabel.querySelector('span').textContent;
                        darkLabel.innerHTML = `<span>${moonEmoji}</span> ${t.darkTheme}`;
                    }
                }
                if (index === 2) {
                    h3.textContent = t.languageSettings;
                }
            });

            // 更新按鈕文字
            document.querySelector('#cancelSettings').textContent = t.cancel;
            document.querySelector('#saveSettings').textContent = t.saveSettings;

            // 更新書籤表單
            const bookmarkForm = document.getElementById('bookmarkForm');
            if (bookmarkForm) {
                // 更新所有輸入框的佔位符
                const inputs = {
                    '#title': t.title_placeholder,
                    '#url': t.url_placeholder,
                    '#description': t.description_placeholder
                };

                // 更新每個輸入框
                Object.entries(inputs).forEach(([selector, placeholder]) => {
                    const input = bookmarkForm.querySelector(selector);
                    if (input) {
                        input.placeholder = placeholder;
                        input.setAttribute('placeholder', placeholder);
                    }
                });

                // 更新類別選擇器
                const categorySelect = bookmarkForm.querySelector('#category');
                if (categorySelect) {
                    categorySelect.innerHTML = `
                        <option value="">${t.selectCategory}</option>
                        <option value="工作">${t.work}</option>
                        <option value="學習">${t.study}</option>
                        <option value="娛樂">${t.entertainment}</option>
                        <option value="其他">${t.other}</option>
                    `;
                }

                // 更新提交按鈕文字
                const submitButton = bookmarkForm.querySelector('button[type="submit"]');
                if (submitButton) {
                    submitButton.textContent = editingId ? t.saveChanges : t.addBookmark;
                }
            }

            // 確保所有輸入框都被更新
            document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(element => {
                const id = element.id;
                switch(id) {
                    case 'title':
                        element.placeholder = t.title_placeholder;
                        break;
                    case 'url':
                        element.placeholder = t.url_placeholder;
                        break;
                    case 'description':
                        element.placeholder = t.description_placeholder;
                        break;
                }
            });

            // 重新渲染書籤列表
            renderBookmarks();

        } catch (error) {
            console.error('更新語言時出錯：', error);
        }
    }

    // 載入保存的設定
    function loadSettings() {
        try {
            // 載入語言設定
            const savedLanguage = localStorage.getItem('language') || 'zh-TW';
            languageSelect.value = savedLanguage;

            // 載入主題設定
            const savedTheme = localStorage.getItem('theme') || 'light';
            const themeInput = document.querySelector(`input[name="theme"][value="${savedTheme}"]`);
            if (themeInput) {
                themeInput.checked = true;
            }
            applyTheme(savedTheme);

            // 載入抬頭名稱
            const savedHeaderTitle = localStorage.getItem('headerTitle');
            if (savedHeaderTitle) {
                mainHeader.textContent = savedHeaderTitle;
            } else {
                mainHeader.textContent = translations[savedLanguage].title;
            }
            
            // 更新臨時標題值
            tempHeaderTitle = mainHeader.textContent;
            
            // 應用語言設定
            updateLanguage(savedLanguage);

        } catch (error) {
            console.error('載入設定時出錯：', error);
        }
    }

    // 頁面載入時初始化設定
    loadSettings();
}); 