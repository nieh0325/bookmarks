class BookmarkManager {
    constructor() {
        this.bookmarks = [];
    }

    // 添加新書籤
    addBookmark(title, url, category, description = '') {
        url = this.formatUrl(url);
        
        const bookmark = {
            id: Date.now(),
            title: title,
            url: url,
            category: category,
            description: description,
            createdAt: new Date().toISOString()
        };
        
        this.bookmarks.push(bookmark);
        this.saveBookmarks();
        return bookmark;
    }

    // 修改書籤
    editBookmark(id, newData) {
        const index = this.bookmarks.findIndex(b => b.id === id);
        if (index !== -1) {
            if (newData.url) {
                newData.url = this.formatUrl(newData.url);
            }
            this.bookmarks[index] = {
                ...this.bookmarks[index],
                ...newData,
                id: id // 保持 ID 不變
            };
            this.saveBookmarks();
            return true;
        }
        return false;
    }

    // 格式化 URL
    formatUrl(url) {
        // 移除空格
        url = url.trim();
        
        // 如果已經有 http:// 或 https:// 則直接返回
        if (url.startsWith('http://') || url.startsWith('https://')) {
            return url;
        }
        
        // 移除開頭的 www. 如果存在
        if (url.startsWith('www.')) {
            url = url.slice(4);
        }
        
        // 直接添加 https://
        return 'https://' + url;
    }

    // 獲取所有書籤
    getAllBookmarks() {
        return this.bookmarks;
    }

    // 刪除書籤
    deleteBookmark(id) {
        this.bookmarks = this.bookmarks.filter(bookmark => bookmark.id !== id);
        this.saveBookmarks();
    }

    // 將書籤保存到本地存儲
    saveBookmarks() {
        localStorage.setItem('bookmarks', JSON.stringify(this.bookmarks));
    }

    // 從本地存儲加載書籤
    loadBookmarks() {
        const savedBookmarks = localStorage.getItem('bookmarks');
        this.bookmarks = savedBookmarks ? JSON.parse(savedBookmarks) : [];
    }
} 